package fr.eseo.gpi.beanartist.tests.controleur.actions;

public class ActionEffacerTest {

}
