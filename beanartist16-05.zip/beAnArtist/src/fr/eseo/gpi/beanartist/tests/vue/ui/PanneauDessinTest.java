package fr.eseo.gpi.beanartist.tests.vue.ui;

public class PanneauDessinTest {

	public static void main(String args[]){
		
	}
	
}
