package fr.eseo.gpi.beanartist;

import fr.eseo.gpi.beanartist.vue.ui.FenêtreBeAnArtist;
import fr.eseo.gpi.beanartist.vue.ui.PanneauDessin;
import java.awt.Color;

public class BeAnArtist {

	public static void main(String[] args) {
		FenêtreBeAnArtist fen = new FenêtreBeAnArtist("BeAnArtist",800, 600,Color.WHITE);
	}
}
