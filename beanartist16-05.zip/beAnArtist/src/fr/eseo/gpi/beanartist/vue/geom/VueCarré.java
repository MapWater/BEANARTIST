package fr.eseo.gpi.beanartist.vue.geom;

import java.awt.Color;

import fr.eseo.gpi.beanartist.modele.geom.Carr�;

public class VueCarr� extends VueRectangle {

	public VueCarr�() {
		// TODO Auto-generated constructor stub
	}

	public VueCarr�(Carr� carr�, boolean rempli) {
		super(carr�, rempli);
		// TODO Auto-generated constructor stub
	}

	public VueCarr�(Carr� carr�, Color couleurLigne, boolean rempli) {
		super(carr�, couleurLigne, rempli);
		// TODO Auto-generated constructor stub
	}

}
